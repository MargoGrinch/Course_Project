#ifndef RESULT_H
#define RESULT_H
void run();
#endif // RESULT_H
