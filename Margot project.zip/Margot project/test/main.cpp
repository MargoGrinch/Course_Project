#include "result.h"
#include <conio.h>
using namespace std;

int main()
{
    run();
    getch();
    return 0;
}
